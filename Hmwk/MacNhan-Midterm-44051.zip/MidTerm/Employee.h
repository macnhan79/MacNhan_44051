/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Employee.h
 * Author: rcc
 *
 * Created on April 18, 2017, 1:48 PM
 */

#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <string>

struct Employee {
    string name;
    string address;
    int hoursWorked;
    float rateOfPay;
    float totalPay;
};

#endif /* EMPLOYEE_H */

