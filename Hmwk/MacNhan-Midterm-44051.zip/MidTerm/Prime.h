/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Prime.h
 * Author: rcc
 *
 * Created on April 24, 2017, 12:54 PM
 */

#ifndef PRIME_H
#define PRIME_H

struct Prime{
	unsigned char prime;
	unsigned char power;
};

#endif /* PRIME_H */

