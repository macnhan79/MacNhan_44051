/* 
 * File:   Player.h
 * Author: admin
 *
 * Created on March 23, 2017, 1:23 AM
 */

#ifndef PLAYER_H
#define	PLAYER_H

struct Player {
    string name;
    int number;
    int point;
};


#endif	/* PLAYER_H */

