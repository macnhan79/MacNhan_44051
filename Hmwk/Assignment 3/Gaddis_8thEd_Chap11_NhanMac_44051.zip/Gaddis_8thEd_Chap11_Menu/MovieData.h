/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MovieData.h
 * Author: rcc
 *
 * Created on March 22, 2017, 7:44 PM
 */

#ifndef MOVIEDATA_H
#define MOVIEDATA_H

struct MovieData {
    string title;
    string director;
    int yearRelease;
    int runningTime;
    float productionCost;
    float firstYearRevenues;
};

#endif /* MOVIEDATA_H */

