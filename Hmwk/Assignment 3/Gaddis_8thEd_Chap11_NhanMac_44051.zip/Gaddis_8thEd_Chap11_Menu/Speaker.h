/* 
 * File:   Speaker.h
 * Author: admin
 *
 * Created on March 26, 2017, 2:55 PM
 */

#ifndef SPEAKER_H
#define	SPEAKER_H

struct Speaker {
    string name;
    string telephone;
    string speakingTopic;
    float fee;
};

#endif	/* SPEAKER_H */

