/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SaleData.h
 * Author: rcc
 *
 * Created on April 5, 2017, 8:43 PM
 */

#ifndef SALEDATA_H
#define SALEDATA_H

struct SaleData {
    string DivisionName;
    int quarter;
    float quarterSales;
};

#endif /* SALEDATA_H */

