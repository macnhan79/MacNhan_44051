/* 
 * File:   SaleData.h
 * Author: admin
 *
 * Created on April 2, 2017, 11:48 PM
 */

#ifndef SALEDATA_H
#define	SALEDATA_H

struct SaleData {
    string DivisionName;
    int quarter;
    float quarterSales;
};

#endif	/* SALEDATA_H */

