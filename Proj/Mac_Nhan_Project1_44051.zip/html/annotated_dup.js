var annotated_dup =
[
    [ "Scores", "struct_scores.html", "struct_scores" ]
];