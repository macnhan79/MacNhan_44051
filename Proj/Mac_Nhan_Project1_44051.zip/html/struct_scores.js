var struct_scores =
[
    [ "name", "struct_scores.html#adc73cbe7efd07c64771ce7b0ef6c8a74", null ],
    [ "rank", "struct_scores.html#aab2bf0fee1a8c2b6e85862c526ddbfae", null ],
    [ "scores", "struct_scores.html#adc160fc30f754360378856a273fef5e2", null ]
];