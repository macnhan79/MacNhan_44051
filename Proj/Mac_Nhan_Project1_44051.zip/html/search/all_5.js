var searchData=
[
  ['operators',['OPERATORS',['../main_8cpp.html#a6a0126712073a760a113eb6bf609a101',1,'main.cpp']]]
];
