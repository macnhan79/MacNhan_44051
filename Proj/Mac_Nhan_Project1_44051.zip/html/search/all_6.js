var searchData=
[
  ['printscorefromfile',['printScoreFromFile',['../main_8cpp.html#aa9e2f4fa572de7c33b9f5827c8df80d9',1,'main.cpp']]]
];
