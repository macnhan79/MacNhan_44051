var searchData=
[
  ['rank',['rank',['../struct_scores.html#aab2bf0fee1a8c2b6e85862c526ddbfae',1,'Scores']]],
  ['round_5feach_5flevel',['ROUND_EACH_LEVEL',['../main_8cpp.html#af57e50e3cf2cfbab4159f73ea5529bc7',1,'main.cpp']]]
];
