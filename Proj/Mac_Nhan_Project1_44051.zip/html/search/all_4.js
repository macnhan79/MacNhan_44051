var searchData=
[
  ['name',['name',['../struct_scores.html#adc73cbe7efd07c64771ce7b0ef6c8a74',1,'Scores']]],
  ['number_5fof_5flevel',['NUMBER_OF_LEVEL',['../main_8cpp.html#a5419937581bd24dcb4b1389600d6545c',1,'main.cpp']]]
];
