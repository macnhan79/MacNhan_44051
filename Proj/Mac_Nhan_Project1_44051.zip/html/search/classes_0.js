var searchData=
[
  ['scores',['Scores',['../struct_scores.html',1,'']]]
];
