var files =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Scores.h", "_scores_8h.html", [
      [ "Scores", "struct_scores.html", "struct_scores" ]
    ] ]
];