var main_8cpp =
[
    [ "calcTime", "main_8cpp.html#ab79ddeff88572509e29cdbb53f44513c", null ],
    [ "callMainMenu", "main_8cpp.html#a90af5f9e863cf3585d8ed4c9db2430be", null ],
    [ "checkPrimeNumber", "main_8cpp.html#aa71e09c066a6e1173d1d4825faf26dd7", null ],
    [ "cinValidNumber", "main_8cpp.html#a786b5791dd8654700760b141e6e1f8cd", null ],
    [ "countScores", "main_8cpp.html#a6317ba9d7cf2637f0bdd8bee612d1ff9", null ],
    [ "generationOperation", "main_8cpp.html#a154f4813e0aef592577bdf7a17d9e574", null ],
    [ "getRandomNumber", "main_8cpp.html#af7bea7d5c8396af5f65b9505cfa9ad6c", null ],
    [ "getRandomOperations", "main_8cpp.html#a63701da917ff4092541dd0054336c1f8", null ],
    [ "main", "main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "printScoreFromFile", "main_8cpp.html#aa9e2f4fa572de7c33b9f5827c8df80d9", null ],
    [ "save", "main_8cpp.html#a642965152f937b2dde70b0419be7bcdf", null ],
    [ "startGame", "main_8cpp.html#a036f38352ddc56207c1a0e198071cf04", null ],
    [ "FILE_NAME", "main_8cpp.html#a890e4d32b647f2b9a858c89daf7cc89f", null ],
    [ "NUMBER_OF_LEVEL", "main_8cpp.html#a5419937581bd24dcb4b1389600d6545c", null ],
    [ "OPERATORS", "main_8cpp.html#a6a0126712073a760a113eb6bf609a101", null ],
    [ "ROUND_EACH_LEVEL", "main_8cpp.html#af57e50e3cf2cfbab4159f73ea5529bc7", null ],
    [ "SCORE_TIME", "main_8cpp.html#a932e57f367ea7a341192a5c6a9fa546a", null ],
    [ "SIZE_SCORE_TO_FILE", "main_8cpp.html#a457a39c21d264e910760e1661c524c41", null ],
    [ "SIZE_TIME_SCORES", "main_8cpp.html#a85099db1e9276ead960f23d9255a3a4b", null ]
];