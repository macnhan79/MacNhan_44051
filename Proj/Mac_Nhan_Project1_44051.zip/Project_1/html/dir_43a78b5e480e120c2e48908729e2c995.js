var dir_43a78b5e480e120c2e48908729e2c995 =
[
    [ "build", "dir_dba76c7f9d63d800c9bb0f8742298038.html", "dir_dba76c7f9d63d800c9bb0f8742298038" ],
    [ "nbproject", "dir_ad35b394f9afc3fd5f9e018c165e3935.html", "dir_ad35b394f9afc3fd5f9e018c165e3935" ],
    [ ".dep.inc", "_8dep_8inc.html", null ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Scores.h", "_scores_8h.html", [
      [ "Scores", "struct_scores.html", "struct_scores" ]
    ] ]
];